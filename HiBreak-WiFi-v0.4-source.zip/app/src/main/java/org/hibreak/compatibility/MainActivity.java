package org.hibreak.compatibility;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiNetworkSuggestion;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * E Ink-friendly, no Wi-Fi picker. Uses Android Wi-Fi suggestions, not privileged APIs.
 * Location + Nearby devices require initial administrator approval.
 */
public final class MainActivity extends Activity {
    private static final int PERMISSIONS_CODE = 501;
    private static final int BG = Color.rgb(248, 249, 246);
    private static final int INK = Color.rgb(25, 37, 38);
    private static final int MUTED = Color.rgb(88, 103, 103);
    private static final int BORDER = Color.rgb(194, 204, 199);
    private static final int GREEN = Color.rgb(29, 91, 68);
    private static final int TEAL = Color.rgb(32, 83, 91);
    private static final int PALE_GREEN = Color.rgb(230, 244, 233);
    private static final int PALE_BLUE = Color.rgb(233, 242, 246);
    private static final int AMBER = Color.rgb(115, 73, 10);
    private static final int PALE_AMBER = Color.rgb(252, 245, 222);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WifiManager wifi;
    private LinearLayout content;
    private TextView status;
    private boolean scanInProgress = false;
    private String notice = "";
    private final List<ScanResult> nearby = new ArrayList<>();
    private boolean hasScanResults = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        showHome();
    }

    @Override protected void onResume() {
        super.onResume();
        if (content != null && status != null) updateStatus();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
    private boolean wifiEnabled() {
        if (wifi == null) return false;
        try { return wifi.isWifiEnabled(); }
        catch (RuntimeException e) { return false; }
    }
    private int dp(float n) { return (int) (n * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable fill(int color, int border, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (border != Color.TRANSPARENT) d.setStroke(dp(1), border);
        return d;
    }

    private LinearLayout column() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        return box;
    }
    private LinearLayout row() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        return box;
    }
    private TextView label(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setIncludeFontPadding(true);
        return t;
    }
    private void verticalSpace(LinearLayout parent, int height) {
        View v = new View(this);
        parent.addView(v, new LinearLayout.LayoutParams(1, dp(height)));
    }
    private LinearLayout.LayoutParams margins(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }
    private void addText(LinearLayout p, String s, int size, int color, boolean bold, int top) {
        p.addView(label(s, size, color, bold), margins(0, top, 0, 0));
    }
    private LinearLayout card(int bg) {
        LinearLayout c = column();
        c.setPadding(dp(18), dp(17), dp(18), dp(17));
        c.setBackground(fill(bg, BORDER, 15));
        return c;
    }
    private void addCard(LinearLayout p, LinearLayout c, int top) {
        p.addView(c, margins(0, top, 0, 0));
    }
    private TextView action(String txt, int bg, int fg, Runnable click) {
        TextView b = label(txt, 15, fg, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(14), dp(13), dp(14), dp(13));
        b.setMinHeight(dp(49));
        b.setBackground(fill(bg, bg == BG ? BORDER : Color.TRANSPARENT, 11));
        b.setOnClickListener(v -> click.run());
        return b;
    }
    private void fullButton(LinearLayout parent, String txt, int bg, int fg, Runnable click, int top) {
        parent.addView(action(txt, bg, fg, click), margins(0, top, 0, 0));
    }
    private void page(String title, String kicker, boolean back) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        content = column();
        content.setPadding(dp(20), dp(24), dp(20), dp(32));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        setContentView(scroll);
        if (back) {
            TextView backBtn = action("‹  BACK TO WI-FI", BG, TEAL, this::showHome);
            backBtn.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
            content.addView(backBtn, margins(0, 0, 0, 12));
        }
        addText(content, kicker, 12, GREEN, true, 0);
        addText(content, title, 31, INK, true, 3);
    }

    private boolean hasLocation() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }
    private boolean hasNearby() {
        return Build.VERSION.SDK_INT < 33 ||
                checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED;
    }
    private boolean scanReady() {
        if (!hasLocation() || !hasNearby()) return false;
        LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        return lm != null && lm.isLocationEnabled();
    }
    private void askForPermissions() {
        List<String> permissions = new ArrayList<>();
        if (!hasLocation()) { permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION); permissions.add(Manifest.permission.ACCESS_FINE_LOCATION); }
        if (Build.VERSION.SDK_INT >= 33 && !hasNearby())
            permissions.add(Manifest.permission.NEARBY_WIFI_DEVICES);
        if (!permissions.isEmpty()) {
            requestPermissions(permissions.toArray(new String[0]), PERMISSIONS_CODE);
        } else {
            notice = "Permissions were granted. If scanning still fails, an administrator should verify Location is enabled.";
            showHome();
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if (requestCode == PERMISSIONS_CODE) {
            notice = (hasLocation() && hasNearby())
                    ? "Permission setup complete. First network addition may require one more Android approval."
                    : "Permissions are still restricted. Ask your administrator to approve them during setup.";
            showHome();
        }
    }

    private String connectedSsid() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            NetworkCapabilities cap = cm.getNetworkCapabilities(cm.getActiveNetwork());
            if (cap == null || !cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return null;
            @SuppressWarnings("deprecation") WifiInfo info = wifi.getConnectionInfo();
            if (info == null) return "Wi-Fi connected";
            String name = info.getSSID();
            if (name == null || name.equals("<unknown ssid>")) return "Wi-Fi connected";
            if (name.length() >= 2 && name.startsWith("\"") && name.endsWith("\""))
                name = name.substring(1, name.length()-1);
            return name;
        } catch (RuntimeException e) {
            return "Connection status unavailable";
        }
    }
    private List<WifiNetworkSuggestion> managed() {
        try { return wifi.getNetworkSuggestions(); }
        catch (RuntimeException e) { return new ArrayList<>(); }
    }
    private WifiNetworkSuggestion findManaged(String ssid) {
        for (WifiNetworkSuggestion s : managed()) if (ssid.equals(s.getSsid())) return s;
        return null;
    }

    private void showHome() {
        page("Wi-Fi", "HIBREAK  /  CONNECT", false);
        addText(content, "Connect without opening Android Settings", 14, MUTED, false, 6);
        LinearLayout current = card(PALE_GREEN);
        addText(current, "CURRENT CONNECTION", 12, GREEN, true, 0);
        status = label("Checking…", 22, INK, true);
        current.addView(status, margins(0, 6, 0, 0));
        addText(current, "Updates when this screen opens or you refresh.", 12, MUTED, false, 5);
        addCard(content, current, 21);
        updateStatus();

        if (!TextUtils.isEmpty(notice)) {
            LinearLayout tip = card(PALE_BLUE);
            addText(tip, notice, 14, INK, false, 0);
            addCard(content, tip, 13);
        }
        if (!hasLocation() || !hasNearby()) {
            LinearLayout permission = card(PALE_AMBER);
            addText(permission, "ADMINISTRATOR SETUP NEEDED", 12, AMBER, true, 0);
            addText(permission, "Your administrator can approve Nearby devices and Precise location during setup. No settings shortcut is used.", 14, INK, false, 8);
            fullButton(permission, "Request setup permissions", AMBER, Color.WHITE, this::askForPermissions, 13);
            addCard(content, permission, 14);
        } else if (!scanReady()) {
            LinearLayout permission = card(PALE_AMBER);
            addText(permission, "LOCATION SERVICES OFF", 12, AMBER, true, 0);
            addText(permission, "Android requires the device Location switch on for nearby Wi-Fi scanning. Ask your administrator to enable it during setup.", 14, INK, false, 8);
            addCard(content, permission, 14);
        }
        if (!wifiEnabled()) {
            LinearLayout permission = card(PALE_AMBER);
            addText(permission, "WI-FI IS OFF", 12, AMBER, true, 0);
            addText(permission, "Android doesn't allow this app to turn Wi-Fi on. Your administrator must enable Wi-Fi first.", 14, INK, false, 8);
            addCard(content, permission, 14);
        }
        fullButton(content, "＋  Add a network manually", GREEN, Color.WHITE,
                () -> showAdd("", "WPA2"), 18);
        fullButton(content, "↻  Scan nearby networks", TEAL, Color.WHITE, this::requestScan, 9);

        addText(content, "NEARBY", 16, INK, true, 26);
        addText(content, "Tap a network to add it to Android's auto-connect suggestions.", 13, MUTED, false, 4);
        if (nearby.isEmpty()) {
            LinearLayout empty = card(Color.WHITE);
            addText(empty, hasScanResults ? "No networks were found." : "Tap Scan to look for nearby networks.", 14, MUTED, false, 0);
            addCard(content, empty, 10);
        } else {
            for (ScanResult r : nearby) networkCard(r);
        }

        addText(content, "MANAGED BY THIS APP", 16, INK, true, 26);
        addText(content, "Android stores these suggestions; they aren't the phone's complete saved Wi-Fi list.", 13, MUTED, false, 4);
        List<WifiNetworkSuggestion> owned = managed();
        if (owned.isEmpty()) {
            LinearLayout empty = card(Color.WHITE);
            addText(empty, "No networks added yet.", 14, MUTED, false, 0);
            addCard(content, empty, 10);
        } else {
            Set<String> shown = new HashSet<>();
            for (WifiNetworkSuggestion s : owned) {
                if (shown.add(s.getSsid())) savedCard(s);
            }
        }
        addText(content, "ANDROID CONNECTION RULES", 13, GREEN, true, 25);
        addText(content, "This app submits auto-connect suggestions. Android chooses when and whether to join. The first suggestion may trigger one administrator-approved system dialog. Later suggestions normally need no repeat approval, unless permissions or policy change.",
                13, MUTED, false, 7);
        addText(content, "Version 0.4 • Offline • No accounts • No analytics", 12, MUTED, false, 18);
    }
    private void updateStatus() {
        if (status == null) return;
        if (!wifiEnabled()) status.setText("Wi-Fi is OFF");
        else {
            String network = connectedSsid();
            status.setText(network == null ? "Not connected" : network);
        }
    }
    private void networkCard(ScanResult scan) {
        String ssid = scan.SSID;
        String sec = classify(scan.capabilities);
        WifiNetworkSuggestion owned = findManaged(ssid);
        LinearLayout c = card(Color.WHITE);
        LinearLayout heading = row();
        TextView name = label(ssid, 17, INK, true);
        heading.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        String signal = scan.level > -57 ? "▂▄▆█" : scan.level > -70 ? "▂▄▆" : "▂▄";
        heading.addView(label(signal, 15, GREEN, true));
        c.addView(heading);
        addText(c, (owned == null ? sec : "Managed • " + sec) + "  ·  " + (scan.frequency >= 4900 ? "5/6 GHz" : "2.4 GHz"),
                12, MUTED, false, 4);
        c.setOnClickListener(v -> {
            if (owned != null) showSaved(ssid);
            else if ("Enterprise".equals(sec) || "Unsupported".equals(sec)) showUnsupported(ssid, sec);
            else showAdd(ssid, sec);
        });
        addCard(content, c, 9);
    }
    private void savedCard(WifiNetworkSuggestion s) {
        LinearLayout c = card(Color.WHITE);
        addText(c, s.getSsid(), 17, INK, true, 0);
        addText(c, "Saved suggestion  ›  Tap to manage", 12, GREEN, false, 5);
        c.setOnClickListener(v -> showSaved(s.getSsid()));
        addCard(content, c, 9);
    }
    private String classify(String caps) {
        String v = caps == null ? "" : caps.toUpperCase(Locale.US);
        if (v.contains("EAP") || v.contains("802.1X")) return "Enterprise";
        if (v.contains("WEP") || v.contains("WAPI")) return "Unsupported";
        if (v.contains("PSK")) return "WPA2"; // Supports mixed WPA2/WPA3 access points.
        if (v.contains("SAE")) return "WPA3";
        if (v.contains("OWE")) return "Enhanced Open";
        return "Open";
    }
    private void requestScan() {
        if (!wifiEnabled()) { notice = "Wi-Fi is off. Ask your administrator to enable it."; showHome(); return; }
        if (!scanReady()) { notice = "Scanning requires location services plus Nearby devices and Precise location permissions."; showHome(); return; }
        if (scanInProgress) return;
        scanInProgress = true;
        notice = "Scanning. If Android limits refreshes, cached results are shown.";
        showHome();
        boolean requested = false;
        try { requested = wifi.startScan(); }
        catch (RuntimeException e) { notice = "Could not request a scan: " + e.getClass().getSimpleName(); }
        // Refresh using the latest results even when Android throttles manual scans.
        final boolean launched = requested;
        handler.postDelayed(() -> {
            scanInProgress = false;
            try {
                List<ScanResult> results = new ArrayList<>(wifi.getScanResults());
                Set<String> seen = new HashSet<>();
                nearby.clear();
                Collections.sort(results, (a, b) -> Integer.compare(b.level, a.level));
                for (ScanResult r : results) {
                    if (r.SSID == null || r.SSID.trim().isEmpty() || !seen.add(r.SSID)) continue;
                    nearby.add(r);
                    if (nearby.size() >= 30) break;
                }
                hasScanResults = true;
                notice = launched ? "Scan complete. Tap a network to continue."
                        : "Android limited the new scan; showing its most recent scan results.";
            } catch (RuntimeException e) {
                notice = "Scan blocked. Check Location permissions and your administrator's app restrictions.";
            }
            showHome();
        }, 2500);
    }

    private void showUnsupported(String ssid, String type) {
        page("Not supported yet", "NETWORK TYPE", true);
        LinearLayout c = card(PALE_AMBER);
        addText(c, ssid, 21, INK, true, 0);
        addText(c, type + " networks aren't supported by version 0.1. Enterprise networks need additional credentials or certificates; older WEP networks are intentionally excluded.",
                14, MUTED, false, 10);
        addCard(content, c, 20);
    }
    private EditText field(String hint, String value, boolean password) {
        EditText input = new EditText(this);
        input.setTextSize(18);
        input.setSingleLine(true);
        input.setTextColor(INK);
        input.setHintTextColor(MUTED);
        input.setPadding(dp(13), dp(13), dp(13), dp(13));
        input.setBackground(fill(Color.WHITE, BORDER, 10));
        input.setHint(hint);
        input.setText(value);
        input.setSelectAllOnFocus(false);
        input.setInputType(password
                ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD
                : InputType.TYPE_CLASS_TEXT);
        return input;
    }
    private void showAdd(String ssid, String originalSecurity) {
        final String[] security = {originalSecurity};
        page("Add network", "YOUR CUSTOM CONNECTION SCREEN", true);
        addText(content, "Name (SSID)", 14, INK, true, 20);
        EditText network = field("Wi-Fi name", ssid, false);
        content.addView(network, margins(0, 7, 0, 0));
        addText(content, "Security type", 14, INK, true, 20);
        LinearLayout[] securityLine = {null};
        securityLine[0] = row();
        TextView typeText = label("", 15, INK, true);
        updateSecurityRow(securityLine[0], typeText, security);
        content.addView(securityLine[0], margins(0, 8, 0, 0));
        addText(content, "Password", 14, INK, true, 20);
        EditText password = field("Enter Wi-Fi password", "", true);
        content.addView(password, margins(0, 7, 0, 0));
        CheckBox showPassword = new CheckBox(this);
        showPassword.setText("Show password");
        showPassword.setTextSize(14);
        showPassword.setTextColor(INK);
        showPassword.setButtonTintList(android.content.res.ColorStateList.valueOf(GREEN));
        showPassword.setOnCheckedChangeListener((button, checked) -> {
            int start = password.getSelectionStart();
            password.setInputType(checked ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            password.setSelection(Math.max(0, Math.min(password.length(), start)));
        });
        content.addView(showPassword, margins(0, 7, 0, 0));
        final TextView error = label("", 13, Color.rgb(145, 30, 25), true);
        content.addView(error, margins(0, 8, 0, 0));
        fullButton(content, "Save for automatic connection", GREEN, Color.WHITE, () -> {
            String name = network.getText().toString().trim();
            String pass = password.getText().toString();
            if (name.isEmpty() || name.length() > 32) {
                error.setText("Enter a Wi-Fi name (1–32 characters)."); return;
            }
            boolean secured = security[0].equals("WPA2") || security[0].equals("WPA3");
            if (secured && (pass.length() < 8 || pass.length() > 63)) {
                error.setText("Enter the network password (8–63 characters)."); return;
            }
            if (findManaged(name) != null) {
                error.setText("This app already manages that network. Remove it before adding it again."); return;
            }
            if (!hasNearby()) { error.setText("Administrator must approve Nearby devices permission first."); return; }
            try {
                WifiNetworkSuggestion.Builder builder = new WifiNetworkSuggestion.Builder().setSsid(name)
                        .setIsInitialAutojoinEnabled(true);
                if (security[0].equals("WPA2")) builder.setWpa2Passphrase(pass);
                else if (security[0].equals("WPA3")) builder.setWpa3Passphrase(pass);
                else if (security[0].equals("Enhanced Open")) builder.setIsEnhancedOpen(true);
                WifiNetworkSuggestion suggestion = builder.build();
                int result = wifi.addNetworkSuggestions(Collections.singletonList(suggestion));
                if (result == WifiManager.STATUS_NETWORK_SUGGESTIONS_SUCCESS) {
                    ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(password.getWindowToken(), 0);
                    notice = "Saved “" + name + "” to Android's Wi-Fi suggestions. It is not necessarily connected yet. If Android asks to approve suggestions, have your administrator approve it.";
                    showHome();
                } else if (result == WifiManager.STATUS_NETWORK_SUGGESTIONS_ERROR_APP_DISALLOWED) {
                    error.setText("Android has not approved Wi-Fi suggestions for this app. Ask your administrator to authorize Wi-Fi control once.");
                } else {
                    error.setText("Android rejected the suggestion (code " + result + "). Check network security and administrator restrictions.");
                }
            } catch (IllegalArgumentException e) {
                error.setText("Invalid network name/password for the selected security type.");
            } catch (SecurityException e) {
                error.setText("An Android permission is blocked. Your administrator must approve it.");
            } catch (RuntimeException e) {
                error.setText("Couldn't save the suggestion: " + e.getClass().getSimpleName());
            }
        }, 19);
        LinearLayout info = card(PALE_BLUE);
        addText(info, "How connections work", 14, TEAL, true, 0);
        addText(info, "Android, not this app, chooses when to join the new network. First-time network suggestion approval may require your administrator; it is normally per app rather than per network.",
                13, MUTED, false, 8);
        addCard(content, info, 16);
    }
    private void updateSecurityRow(LinearLayout line, TextView unused, String[] security) {
        line.removeAllViews();
        final String[] options = {"WPA2", "WPA3", "Open", "Enhanced Open"};
        for (String option : options) {
            TextView b = label(option, 12, option.equals(security[0]) ? Color.WHITE : INK, true);
            b.setBackground(fill(option.equals(security[0]) ? TEAL : Color.WHITE,
                    option.equals(security[0]) ? Color.TRANSPARENT : BORDER, 8));
            b.setGravity(Gravity.CENTER);
            b.setPadding(dp(8), dp(12), dp(8), dp(12));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            lp.setMargins(0, 0, dp(5), 0);
            line.addView(b, lp);
            b.setOnClickListener(v -> {
                security[0] = option;
                updateSecurityRow(line, unused, security);
            });
        }
    }
    private void showSaved(String ssid) {
        page("Managed network", "SAVED BY THIS APP", true);
        LinearLayout c = card(PALE_GREEN);
        addText(c, ssid, 22, INK, true, 0);
        addText(c, "Android has this network as an automatic connection suggestion. This does not guarantee that it is currently connected.",
                14, MUTED, false, 9);
        addCard(content, c, 19);
        fullButton(content, "Remove this network suggestion", Color.rgb(150, 43, 34), Color.WHITE, () -> {
            List<WifiNetworkSuggestion> matches = new ArrayList<>();
            for (WifiNetworkSuggestion s : managed()) if (ssid.equals(s.getSsid())) matches.add(s);
            if (matches.isEmpty()) { notice = "That suggestion was already removed."; showHome(); return; }
            try {
                int statusCode = wifi.removeNetworkSuggestions(matches);
                notice = statusCode == WifiManager.STATUS_NETWORK_SUGGESTIONS_SUCCESS
                        ? "Removed “" + ssid + "” from this app's suggestions."
                        : "Android could not remove the suggestion (code " + statusCode + ").";
            } catch (RuntimeException e) {
                notice = "Removal was blocked by Android permissions or administrator policy.";
            }
            showHome();
        }, 20);
        addText(content, "Removing a suggestion may disconnect the phone if it's using that network. It does not remove Wi-Fi networks saved independently in Android Settings.",
                13, MUTED, false, 15);
    }
}
