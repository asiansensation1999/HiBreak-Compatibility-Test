# HiBreak Wi-Fi Manager — proof of concept (v0.1)

An e-ink-friendly Android application for **Bigme HiBreak Pro Color**. Shows available access points, accepts SSID/password entirely inside the application (no Android Wi-Fi selection popup), saves Wi-Fi suggestions for Android to auto-connect, and displays/removes suggestions created by this app.

**Important:** Android decides whether and when to connect. This is NOT a privileged Wi-Fi switcher. Suggestions are **not** entries in Android's usual saved Wi-Fi list. The app can't read networks previously saved in Android settings, force an immediate Wi-Fi switch, toggle Wi-Fi on, turn Location on, or bypass device-management restrictions. Wi-Fi suggestion permission is normally granted once **per app**, but OS/OEM/device policy can affect the result. Public captive portals and enterprise Wi-Fi aren't supported in v0.1.

## Privacy and security

- No INTERNET permission. The app cannot upload credentials or send data to a remote server.
- No analytics, ads, tracking, accounts, root, Accessibility service or device-admin privileges.
- Network passwords are given to Android's Wi-Fi suggestion API. The app **does not** store passwords in SharedPreferences or a private file.
- It requests Nearby Wi-Fi Devices (Android 13+) and Precise location permission (needed to scan access points); Android Location Services must be on.
- It does not open Android Settings, Wi-Fi picker, or other system settings popups itself.
- Android *may* show permission or suggestion-approval prompts. An administrator (your wife) must approve initial permissions and the first suggestion while Victory Shield allows it. The app does not disable or work around Victory Shield.

## Initial setup (with administrator)

1. Install the debug APK.
2. Keep Wi-Fi and device Location switched **on** (administrator can do this during setup).
3. Open app > **Request setup permissions**. Approve **Precise location** and **Nearby devices** as prompted.
4. Tap **Scan nearby networks**. If access points appear, scanning works.
5. Add an existing accessible network for the first time. Android may show a one-time **Allow Wi-Fi suggestions** dialog/notification. Have the administrator approve it.
6. Restore Victory Shield restrictions. Try adding another Wi-Fi network without opening Settings.

**Not guaranteed:** Android may refuse to connect to a suggestion while another saved Wi-Fi network has higher priority, or if the device policy prevents it. If Victory Shield blocks permission dialogs even during setup, administrator authorization is necessary.

## Build

Requires JDK 17, Android SDK platform 35 and Android Gradle plugin 8.9.2. No third-party runtime libraries.

### Android Studio (computer)

Open this folder as a project. Wait for Gradle sync, then Build > Build APK(s). The APK is at `app/build/outputs/apk/debug/app-debug.apk`.

### GitHub Actions (phone browser, no computer)

A complete `.github/workflows/build-apk.yml` is included. Upload the **project files and folders**, not just the ZIP archive, to a GitHub repository while preserving directory structure. Enable Actions if necessary. The workflow builds the debug APK on push to `main`, or manually via **Actions > Build Android APK > Run workflow**. Download the artifact named **HiBreak-WiFi-debug-APK**, extract its APK, then install it on the HiBreak. This depends on GitHub services and an account, and you'll need to grant installing APKs permission, which Victory Shield may also require administrator authorization for.

## Test checklist

- [ ] APK installed without removing Victory Shield
- [ ] Administrator approves permissions once
- [ ] Wi-Fi and Location on
- [ ] Scan lists nearby networks
- [ ] Add first network; administrator approves Android suggestion request
- [ ] Saved suggestion appears under Managed by this app
- [ ] With Victory Shield active, add a second network and check if Android connects
- [ ] Remove a suggestion and confirm it disappears

## Known limits

- Android scans are throttled; sometimes cached results appear.
- Saved suggestions differ from system-saved Wi-Fi networks.
- No direct connection guarantee; Android controls automatic network selection.
- Supports WPA2-Personal, WPA3-Personal, Enhanced Open and open Wi-Fi (not enterprise, WEP or WAPI).
- Some AP security modes can be reported ambiguously; manually select the appropriate security type.
- No ability to start captive portal login without interaction.
- Color e-ink UI with high contrast and no motion animations.

This code has not been compiled or tested on a physical HiBreak Pro Color in the ChatGPT workspace.
